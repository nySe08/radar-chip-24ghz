"""lo_gen.py - LO core layout generator (IHP SG13G2). Stage 1: VCO + emitter followers wired."""
"""(placement) - LO core placement: VCO (centre-top), emitter followers, RX pre-driver (H-tree root at the bottom),
TX pre-driver (right, output up to the PAs), divider driver + /4 divider (left, output to the PLL pads)."""
from layoutlib import Builder
B = Builder("lo_core"); place = B.place
MIM = lambda w: dict(w=f"{w}u", l=f"{w}u")
def R(key, kind, x, y, w, l, rot=0): place(key, kind, x, y, rot=rot, w=f"{w}u", l=f"{l}u")
X0 = 440.0                                              # symmetry axis of the VCO / emitter followers / RX pre-driver
# ---------------- VCO ----------------
place("Lvco", "inductor3", X0, 400, w="6u", s="2.1u", d="70.88u", nr_r=2, subE=False)     # leads down at y~400
place("Qvco_6", "npn13G2", X0 - 26, 378, Nx=4); place("Qvco_7", "npn13G2", X0 + 14, 378, Nx=4)
place("Cvco_b6", "rfcmim", X0 - 48, 342, **MIM(11.5)); place("Cvco_b7", "rfcmim", X0 + 41.5, 353.5, rot=180, **MIM(11.5))   # mirrored
place("Cvar", "SVaricap", X0 - 5.4, 329.0, rot=270, w="9.74u", l="0.3u", Nx=10)                # G1 left, G2 right, W up
place("Cvco_cv1", "rfcmim", X0 - 78, 326, rot=270, **MIM(11.3)); place("Cvco_cv2", "rfcmim", X0 + 55.5, 326, rot=270, **MIM(11.3))  # PLUS up, MINUS down
R("Rvco_g1", "rhigh", X0 - 22, 300, 1, 7.0); R("Rvco_g2", "rhigh", X0 + 21, 300, 1, 7.0)
R("Rvco_b6", "rppd", X0 - 60, 370, 1, 7.47); R("Rvco_b7", "rppd", X0 + 59, 370, 1, 7.47)
R("Rvco_tail", "rppd", X0 - 1, 360, 2, 1.41)
place("Cvco_gb", "rfcmim", X0 - 134, 330, **MIM(33)); R("Rvco_gb1", "rhigh", X0 - 93, 330, 1, 13.30); R("Rvco_gb2", "rhigh", X0 - 89, 330, 1, 13.30)
place("Cvco_bb", "rfcmim", X0 + 92, 330, **MIM(33)); R("Rvco_bb1", "rppd", X0 + 140, 330, 1, 15.21); R("Rvco_bb2", "rppd", X0 + 145, 330, 1, 22.95)
# ---------------- emitter followers ----------------
place("Qef_1", "npn13G2", X0 - 14, 280, Nx=2); place("Qef_2", "npn13G2", X0 + 8, 280, Nx=2)
R("Ref_1", "rppd", X0 - 26, 262, 2, 8.24); R("Ref_2", "rppd", X0 + 23, 262, 2, 8.24)
# ---------------- drivers (generic: inputs from the emitter followers, outputs via 12 um coupling caps) ----------------
def driver(tag, x, y, rtl, rdl, coil=None, coil_xy=None, coil_rot=0):
    up = tag.upper()
    place(f"C{up}_i1", "rfcmim", x - 50, y + 40, **MIM(25)); place(f"C{up}_i2", "rfcmim", x + 22, y + 40, **MIM(25))
    place(f"Q{up}_a", "npn13G2", x - 14, y + 20, Nx=2); place(f"Q{up}_b", "npn13G2", x + 8, y + 20, Nx=2)
    R(f"R{up}_b1", "rppd", x - 24, y - 8, 1, 19.08); R(f"R{up}_b2", "rppd", x + 23, y - 8, 1, 19.08)
    R(f"R{up}_t", "rppd", x - 1, y - 4, 2, rtl)
    R(f"R{up}_d1", "rppd", x - 30, y + 18, 2, rdl); R(f"R{up}_d2", "rppd", x + 27, y + 18, 2, rdl)
    place(f"C{up}_c1", "rfcmim", x - 44, y - 40, **MIM(12)); place(f"C{up}_c2", "rfcmim", x + 26, y - 40, **MIM(12))
    place(f"C{up}_vb", "rfcmim", x - 105, y - 44, **MIM(33)); R(f"R{up}_v1", "rppd", x - 64, y - 30, 1, 17.53); R(f"R{up}_v2", "rppd", x - 59, y - 30, 1, 20.63)
    if coil: place(f"L{up}", "inductor3", *coil_xy, rot=coil_rot, w=f"{coil[0]}u", s="2.1u", d=f"{coil[1]}u", nr_r=2, subE=False)
driver("prx", X0, 160, 0.94, 2.83, coil=(4, 65.36), coil_xy=(X0 + 64, 192), coil_rot=270)       # RX pre-driver, coil to the right
place("Rbl_r1", "rhigh", X0 - 8, 80, w="1u", l="14.0u"); place("Rbl_r2", "rhigh", X0 + 7, 80, w="1u", l="14.0u")
driver("ptx", X0 + 330, 300, 1.86, 2.83, coil=(4, 83.47), coil_xy=(X0 + 330, 420), coil_rot=0)  # TX pre-driver, coil above
place("Rbl_t1", "rhigh", X0 + 291, 225, w="1u", l="14.0u"); place("Rbl_t2", "rhigh", X0 + 361, 225, w="1u", l="14.0u")
driver("ddv", X0 - 200, 230, 1.86, 2.05)                                                           # divider driver (resistive)
# ---------------- /4 divider (left): bias, 4 latches, output stage ----------------
def latch(tag, x, y, nt, rll, re):
    up = tag.upper()
    R(f"R{up}_lp", "rppd", x, y + 22, 2, rll); R(f"R{up}_ln", "rppd", x + 8, y + 22, 2, rll)
    for i, n in enumerate(("d1", "d2", "h1", "h2")): place(f"Q{up}_{n}", "npn13G2", x + i * 10, y + 10, Nx=1)
    place(f"Q{up}_c1", "npn13G2", x + 5, y, Nx=1); place(f"Q{up}_c2", "npn13G2", x + 25, y, Nx=1)
    place(f"Q{up}_t", "npn13G2", x + 13, y - 12, Nx=nt); R(f"R{up}_e", "rppd", x + 33, y - 16, 4, re)
DX = 12
for i, (tag, nt, rll, re) in enumerate((("dm1", 3, 1.79, 1.28), ("ds1", 3, 1.79, 1.28), ("dm2", 2, 2.83, 2.05), ("ds2", 2, 2.83, 2.05))):
    latch(tag, DX, 60 + i * 50, nt, rll, re)
R("Rdiv_ref", "rppd", 60, 20, 1, 11.34); place("Qdiv_br", "npn13G2", 70, 24, Nx=1); R("Rdiv_ebr", "rppd", 80, 20, 2, 2.05)
place("Cdiv_bt", "rfcmim", 95, 20, **MIM(25))
place("Cdiv_k", "rfcmim", 62, 70, **MIM(33)); R("Rdiv_k1", "rppd", 112, 70, 1, 15.21); R("Rdiv_k2", "rppd", 117, 70, 1, 22.95)
R("Rdiv_ck1", "rppd", 122, 70, 1, 7.47); R("Rdiv_ck2", "rppd", 127, 70, 1, 7.47)
place("Cdiv_c1", "rfcmim", 62, 128, **MIM(18.2)); place("Cdiv_c2", "rfcmim", 94, 128, **MIM(18.2))
R("Rdiv_b1", "rppd", 122, 120, 1, 19.08); R("Rdiv_b2", "rppd", 127, 120, 1, 19.08)
place("Cdiv_bo", "rfcmim", 62, 172, **MIM(33)); R("Rdiv_o1", "rppd", 112, 172, 1, 17.14); R("Rdiv_o2", "rhigh", 117, 172, 1, 5.53)
place("Cdiv_o1", "rfcmim", 12, 280, **MIM(18.2)); place("Cdiv_o2", "rfcmim", 44, 280, **MIM(18.2))
R("Rdiv_bo1", "rppd", 76, 274, 1, 19.08); R("Rdiv_bo2", "rppd", 81, 274, 1, 19.08)
place("Qdiv_o1", "npn13G2", 20, 340, Nx=4); place("Qdiv_o2", "npn13G2", 44, 340, Nx=4)
place("Qdiv_to1", "npn13G2", 16, 324, Nx=10); place("Qdiv_to2", "npn13G2", 44, 324, Nx=10)
R("Rdiv_eo1", "rppd", 18, 310, 8, 0.66); R("Rdiv_eo2", "rppd", 46, 310, 8, 0.66)
R("Rdiv_t1", "rppd", 20, 354, 10, 1.66); R("Rdiv_t2", "rppd", 44, 354, 10, 1.66)

pin, ends, pins_of, rect, wire, via, gnd_via = B.pin, B.ends, B.pins_of, B.rect, B.wire, B.via, B.gnd_via
# ======================= stage 1: VCO + emitter followers =======================
la, lc, lb = pin("Lvco", "LA"), pin("Lvco", "LC"), pin("Lvco", "LB")
q6b, q6c, q6e = pin("Qvco_6", "B"), pin("Qvco_6", "C"), pin("Qvco_6", "E")
q7b, q7c, q7e = pin("Qvco_7", "B"), pin("Qvco_7", "C"), pin("Qvco_7", "E")
cb6p, cb6m, cb7p, cb7m = pin("Cvco_b6", "PLUS"), pin("Cvco_b6", "MINUS"), pin("Cvco_b7", "PLUS"), pin("Cvco_b7", "MINUS")
g1b, g2b, wv = pin("Cvar", "G1"), pin("Cvar", "G2"), pin("Cvar", "W")
cv1p, cv1m, cv2p, cv2m = pin("Cvco_cv1", "PLUS"), pin("Cvco_cv1", "MINUS"), pin("Cvco_cv2", "PLUS"), pin("Cvco_cv2", "MINUS")
cgbp, cgbm, cbbp, cbbm = pin("Cvco_gb", "PLUS"), pin("Cvco_gb", "MINUS"), pin("Cvco_bb", "PLUS"), pin("Cvco_bb", "MINUS")
ef1b, ef1c, ef1e = pin("Qef_1", "B"), pin("Qef_1", "C"), pin("Qef_1", "E")
ef2b, ef2c, ef2e = pin("Qef_2", "B"), pin("Qef_2", "C"), pin("Qef_2", "E")
rg1, rg2, rb6, rb7, rtl = ends("Rvco_g1"), ends("Rvco_g2"), ends("Rvco_b6"), ends("Rvco_b7"), ends("Rvco_tail")
rgb1, rgb2, rbb1, rbb2, ref1, ref2 = ends("Rvco_gb1"), ends("Rvco_gb2"), ends("Rvco_bb1"), ends("Rvco_bb2"), ends("Ref_1"), ends("Ref_2")
XP, XN = la.center().x, lb.center().x                      # vcop / vcon vertical tracks (under the coil leads)
YVB1, YVB2 = 393.0, 290.0                                  # VCC buses (TM2)
wire("TopMetal2", [(300, YVB1), (600, YVB1)], 5); wire("TopMetal2", [(300, YVB2), (600, YVB2)], 5)
wire("TopMetal2", [(300, YVB2), (300, YVB1)], 5); wire("TopMetal2", [(600, YVB2), (600, YVB1)], 5)
rect("TopMetal2", lc.left, YVB1 - 2.5, lc.right, lc.bottom)            # centre tap -> VCC
# tank: leads -> TM1 stubs -> collectors (M1 pads); then TM1 verticals down to the emitter followers
for (ld, qc, xv, xr) in ((la, q6c, XP, (q6c.left, XP + 1.1)), (lb, q7c, XN, (XN - 1.1, q7c.right))):
    rect("TopMetal1", ld.left, 386.5, ld.right, ld.bottom)
    rect("Metal1", xr[0], qc.bottom, xr[1], 389.0); via(xv, 388.0, "Metal1", "TopMetal1")
    wire("TopMetal1", [(xv, 386.5), (xv, 274.0)], 3)
# cross-coupling: vcop -> TM2 (y=352) -> Cb7 outer plate ; vcon -> TM2 (y=343) -> Cb6 outer plate
for (xv, yc, cp) in ((XP, 352.0, cb7p), (XN, 343.0, cb6p)):
    via(xv, yc, "TopMetal1", "TopMetal2"); via(cp.center().x, cp.center().y, "TopMetal1", "TopMetal2")   # via lands on the pin itself
    wire("TopMetal2", [(xv, yc), (cp.center().x, yc), (cp.center().x, cp.center().y)], 4)
# bases: inner cap plate -> via -> M1 -> base bar (pulled down); bias resistor joins at y=373
for (cm, qb, xv, rb) in ((cb6m, q6b, cb6m.right + 1.9, rb6), (cb7m, q7b, cb7m.left - 1.9, rb7)):
    rect("Metal1", qb.left, 369.0, qb.right, qb.top)
    via(xv, cm.center().y, "Metal1", "Metal5"); wire("Metal5", [(cm.center().x, cm.center().y), (xv, cm.center().y)], 2)
    wire("Metal1", [(xv, cm.center().y), (xv, 370.5), ((qb.left + 0.5) if xv < qb.left else (qb.right - 0.5), 370.5)], 1.0)
    wire("Metal1", [(rb[1].center().x, rb[1].center().y), (rb[1].center().x, 374.0), ((qb.left + 0.5) if rb[1].center().x < qb.left else (qb.right - 0.5), 374.0)], 1.0)
    rect("Metal1", min(qb.left, qb.left), 369.0, qb.right, 374.5)
# tail: emitters joined (M2) -> Rtail -> ground
rect("Metal2", q6e.left, q6e.bottom, q7e.right, q6e.top)
rect("Metal1", rtl[1].left, rtl[1].bottom, rtl[1].right, 367.0); via(rtl[1].center().x, 366.2, "Metal1", "Metal2")
wire("Metal2", [(rtl[1].center().x, 366.2), (rtl[1].center().x, q6e.center().y)], 1.2)
wire("Metal1", [(rtl[0].center().x, rtl[0].center().y), (rtl[0].center().x, 355.5)], 1.0); gnd_via(rtl[0].center().x, 355.5, "Metal1")
# vbb (M3 at y=366): Rb6/Rb7 bottoms, Cbb top plate, Rbb1 bottom, Rbb2 top
YB = 365.0
for r in (rb6[0], rb7[0], rbb1[1], rbb2[1]):                # (each divider resistor: the vbb end is the one nearer the bus)
    via(r.center().x, r.center().y, "Metal1", "Metal3"); wire("Metal3", [(r.center().x, r.center().y), (r.center().x, YB)], 1.0)
wire("Metal3", [(rb6[0].center().x, YB), (rbb2[1].center().x, YB)], 1.0)
v = (cbbp.center().x, YB); via(*v, "Metal3", "TopMetal1"); wire("TopMetal1", [v, (cbbp.center().x, cbbp.center().y)], 2)
for r in (rbb1[0], rgb1[1]):                                # VCC ends of the two bias dividers
    up = r is rgb1[1]
    rect("Metal1", r.left, r.bottom - (0 if up else 1.6), r.right, r.top + (1.6 if up else 0))
    yv = r.center().y + (1.0 if up else -1.0); via(r.center().x, yv, "Metal1", "TopMetal2")
    wire("TopMetal2", [(r.center().x, yv), (r.center().x, YVB1)], 4)
for r in (rbb2[0],):
    wire("Metal1", [(r.center().x, r.center().y), (r.center().x, r.center().y - 3.5)], 1.0); gnd_via(r.center().x, r.center().y - 3.5, "Metal1")
# varactor gates: bars -> M1 pads -> M2 -> Ccv output plates + Rg tops (mirrored)
for (gb, cm, rg, sgn) in ((g1b, cv1m, rg1, -1), (g2b, cv2m, rg2, +1)):
    xo = gb.left - 6.0 if sgn < 0 else gb.right + 6.0
    rect("Metal1", min(xo, gb.left), gb.bottom, max(xo, gb.right), gb.top)
    xv = xo + 1.2 * (-sgn); via(xv, gb.bottom + 1.0, "Metal1", "Metal2")
    xc = cm.right + 2.4 if sgn < 0 else cm.left - 2.4
    via(xc, cm.center().y, "Metal2", "Metal5"); wire("Metal5", [(cm.center().x, cm.center().y), (xc, cm.center().y)], 2)
    wire("Metal2", [(xv, gb.bottom + 1.0), (xv, cm.center().y), (xc, cm.center().y)], 1.0)
    via(rg[1].center().x, rg[1].center().y, "Metal1", "Metal2"); wire("Metal2", [(rg[1].center().x, rg[1].center().y), (rg[1].center().x, cm.center().y)], 1.0)
# varactor input plates: vcop -> Ccv1 top (TM1 branch at y=331); vcon -> Ccv2
for (xv, cp) in ((XP, cv1p), (XN, cv2p)):
    wire("TopMetal1", [(xv, 334.0), (cp.center().x, 334.0), (cp.center().x, cp.center().y)], cp.width())   # as wide as the pin
# vgb (M3 at y=296): Rg bottoms -> Cgb top plate, Rgb1 bottom, Rgb2 top
YG = 296.0
for r in (rg1[0], rg2[0]):
    via(r.center().x, r.center().y, "Metal1", "Metal3"); wire("Metal3", [(r.center().x, r.center().y), (r.center().x, YG)], 1.0)
XG = cgbp.left - 3.0
wire("Metal3", [(rg2[0].center().x, YG), (XG, YG), (XG, cgbp.center().y)], 1.0)
v = (XG, cgbp.center().y); via(*v, "Metal3", "TopMetal1"); wire("TopMetal1", [v, (cgbp.center().x, cgbp.center().y)], 2)
for r in (rgb1[0], rgb2[0]):                                 # vgb ends (bottoms), M3 down to the bus
    via(r.center().x, r.center().y, "Metal1", "Metal3"); wire("Metal3", [(r.center().x, r.center().y), (r.center().x, YG)], 1.0)
wire("Metal1", [(rgb2[1].center().x, rgb2[1].center().y), (rgb2[1].center().x, rgb2[1].center().y + 3.5)], 1.0)
gnd_via(rgb2[1].center().x, rgb2[1].center().y + 3.5, "Metal1")
# decap bottom plates -> ground
for cm in (cgbm, cbbm):                                      # ground via straight below the bottom-plate pin (clear of the VCC vias)
    g = (cm.center().x, cm.center().y - 13.0); gnd_via(*g, "Metal5"); wire("Metal5", [(cm.center().x, cm.center().y), g], 2)
# VTUNE: varactor well (W, top) -> M2 -> left edge of the LO core (port)
rect("Metal1", wv.left, wv.bottom, wv.right, 332.6); via(wv.center().x, 331.8, "Metal1", "Metal2")
wire("Metal2", [(wv.center().x, 331.8), (396.0, 331.8), (396.0, 383.0), (6.0, 383.0)], 1.0)
B.text("VTUNE", 7.0, 383.0, gds=(10, 25))
# emitter followers: bases from the tank verticals; collectors to VCC (bus at y=290); emitters -> Ref (efp/efn)
for (xv, eb, ec, ee, rf, sgn) in ((XP, ef1b, ef1c, ef1e, ref1, -1), (XN, ef2b, ef2c, ef2e, ref2, +1)):
    via(xv, 275.0, "Metal1", "TopMetal1"); rect("Metal1", min(eb.left, xv - 1.1), 274.0, max(eb.right, xv + 1.1), eb.top)
    xvc = ec.left - 3.5 if sgn < 0 else ec.right + 3.5                       # collector VCC via, away from the tank track
    rect("Metal1", min(xvc - 1.1, ec.left), ec.bottom, max(xvc + 1.1, ec.right), 291.2); via(xvc, YVB2, "Metal1", "TopMetal2")
    xe = ee.left - 6.0 if sgn < 0 else ee.right + 6.0
    rect("Metal2", min(xe, ee.left), ee.bottom, max(xe, ee.right), ee.top)
    via(rf[1].center().x, rf[1].center().y, "Metal1", "Metal2")
    wire("Metal2", [(xe, ee.center().y), (rf[1].center().x, ee.center().y), (rf[1].center().x, rf[1].center().y)], 1.2)
    wire("Metal1", [(rf[0].center().x, rf[0].center().y), (rf[0].center().x, 257.0)], 1.0); gnd_via(rf[0].center().x, 257.0, "Metal1")
# MIM substrate rings of the VCO -> ground (signal MIMs strap out of their cut-outs)
VCO_SIG = ("Cvco_b6", "Cvco_b7", "Cvco_cv1", "Cvco_cv2")
for k in ("Cvco_gb", "Cvco_bb") + VCO_SIG:
    t = pin(k, "TIE"); tc = t.center()
    if k in VCO_SIG:
        cb = B.DEV[k].dbbox().enlarged(3.0, 3.0); d = tc.y - cb.bottom + 6.0 if tc.y < B.DEV[k].dbbox().center().y else cb.top - tc.y + 6.0
        sgn = -1 if tc.y < B.DEV[k].dbbox().center().y else 1
        gnd_via(tc.x, tc.y, "Metal1", patch=(tc.x - 3, min(tc.y, tc.y + sgn * d), tc.x + 3, max(tc.y, tc.y + sgn * d)))
    else: gnd_via(tc.x, tc.y, "Metal1")
# ======================= ground plane + checks (stage 1) =======================
B.ground_plane((0, 0, 860, 590), hole_keys=("Lvco", "LPRX", "LPTX"), signal_mim_keys=VCO_SIG)
P = {"vcop lead": ("TopMetal1", (la.center().x, 395.0)), "Q6 C": ("Metal1", q6c.center()), "Cb7 +": ("TopMetal1", cb7p.center()), "Ccv1 +": ("TopMetal1", cv1p.center()),
     "EF1 B": ("Metal1", ef1b.center()), "vcon lead": ("TopMetal1", (lb.center().x, 395.0)), "Q7 C": ("Metal1", q7c.center()), "Cb6 +": ("TopMetal1", cb6p.center()),
     "Ccv2 +": ("TopMetal1", cv2p.center()), "EF2 B": ("Metal1", ef2b.center()), "VCC tap": ("TopMetal2", (lc.center().x, 395.0)), "EF1 C": ("Metal1", ef1c.center()),
     "EF2 C": ("Metal1", ef2c.center()), "Rgb1 top": ("Metal1", rgb1[1].center()), "Rbb1 top": ("Metal1", rbb1[0].center()),
     "Q6 B": ("Metal1", q6b.center()), "Cb6 -": ("Metal5", cb6m.center()), "Rb6 top": ("Metal1", rb6[1].center()),
     "Q7 B": ("Metal1", q7b.center()), "Cb7 -": ("Metal5", cb7m.center()), "Rb7 top": ("Metal1", rb7[1].center()),
     "Q6 E": ("Metal2", q6e.center()), "Q7 E": ("Metal2", q7e.center()), "Rtail top": ("Metal1", rtl[1].center()),
     "Rb6 bot": ("Metal1", rb6[0].center()), "Rb7 bot": ("Metal1", rb7[0].center()), "Cbb +": ("TopMetal1", cbbp.center()),
     "Rbb1 bot": ("Metal1", rbb1[1].center()), "Rbb2 top": ("Metal1", rbb2[1].center()),
     "G1": ("Metal1", g1b.center()), "Ccv1 -": ("Metal5", cv1m.center()), "Rg1 top": ("Metal1", rg1[1].center()),
     "G2": ("Metal1", g2b.center()), "Ccv2 -": ("Metal5", cv2m.center()), "Rg2 top": ("Metal1", rg2[1].center()),
     "Rg1 bot": ("Metal1", rg1[0].center()), "Rg2 bot": ("Metal1", rg2[0].center()), "Cgb +": ("TopMetal1", cgbp.center()),
     "Rgb1 bot": ("Metal1", rgb1[0].center()), "Rgb2 top": ("Metal1", rgb2[0].center()), "W": ("Metal1", wv.center()), "VTUNE": ("Metal2", (7, 383)),
     "EF1 E": ("Metal2", ef1e.center()), "Ref1 top": ("Metal1", ref1[1].center()), "EF2 E": ("Metal2", ef2e.center()), "Ref2 top": ("Metal1", ref2[1].center()),
     "GND": ("Metal4", (3, 587)), "Rtail bot": ("Metal1", rtl[0].center()), "Rbb2 bot": ("Metal1", rbb2[0].center()), "Rgb2 bot": ("Metal1", rgb2[1].center()),
     "Ref1 bot": ("Metal1", ref1[0].center()), "Ref2 bot": ("Metal1", ref2[0].center()), "Cgb -": ("Metal5", cgbm.center()), "Cbb -": ("Metal5", cbbm.center()),
     **{f"{k} TIE": ("Metal1", pin(k, "TIE").center()) for k in ("Cvco_gb", "Cvco_bb") + VCO_SIG}}
G_ = [["vcop lead", "Q6 C", "Cb7 +", "Ccv1 +", "EF1 B"], ["vcon lead", "Q7 C", "Cb6 +", "Ccv2 +", "EF2 B"],
      ["VCC tap", "EF1 C", "EF2 C", "Rgb1 top", "Rbb1 top"], ["Q6 B", "Cb6 -", "Rb6 top"], ["Q7 B", "Cb7 -", "Rb7 top"],
      ["Q6 E", "Q7 E", "Rtail top"], ["Rb6 bot", "Rb7 bot", "Cbb +", "Rbb1 bot", "Rbb2 top"], ["G1", "Ccv1 -", "Rg1 top"], ["G2", "Ccv2 -", "Rg2 top"],
      ["Rg1 bot", "Rg2 bot", "Cgb +", "Rgb1 bot", "Rgb2 top"], ["W", "VTUNE"], ["EF1 E", "Ref1 top"], ["EF2 E", "Ref2 top"],
      ["GND", "Rtail bot", "Rbb2 bot", "Rgb2 bot", "Ref1 bot", "Ref2 bot", "Cgb -", "Cbb -"] + [f"{k} TIE" for k in ("Cvco_gb", "Cvco_bb") + VCO_SIG]]
if __name__ == "__main__":
    B.connectivity(P, G_); B.mini_drc(); B.foreign_in_inductors()
    B.write("lo_core.gds")
